class FridgeFood{
  String name;
  String quant;
  String exp;

  FridgeFood(this.name, this.quant, this.exp);


}